<?php require_once("include/db.php"); ?>
<?php require_once("include/sessions.php"); ?>
<?php require_once("include/Funtions.php"); ?>
<?php

if(isset($_POST["submit"])){
    $Name = mysqli_real_escape_string($connection, $_POST["name"]);
    $Email = mysqli_real_escape_string($connection, $_POST["email"]);
    $Comment = mysqli_real_escape_string($connection, $_POST["comment"]);
    $CurrentTime=time();
    $DateTime=strftime("%B-%d-%Y %H:%M:%S", $CurrentTime);
    $DateTime;
    $PostId= $_GET["id"];
    echo $Name ; 
    echo $Email ;
    echo $Comment ;
    if(empty($Name)){
        $_SESSION["ERRORMessage"] =  "All fields are required";
    }elseif(strlen($Comment) >500){
        $_SESSION["ERRORMessage"] =  "Comment cannot be above 500 characters";
    }else{
        global $connection;
        $PostIDFromURL=$_GET['id'];
        $Query="INSERT INTO test (datetime, name, email, comment, status, admin_panel_id)
        VALUES ('$DateTime', '$Name', '$Email', '$Comment', 'OFF', '$PostIDFromURL')";
        $Execute= mysqli_query($connection, $Query);
        if($Execute){
            $_SESSION["SuccessMessage"] =  "Comment Submitted Successfully";
            Redirect_to("FullPost.php?id={$PostId}");
            
        }else{
            $_SESSION["ERRORMessage"] =  "Failed to Submit Post";
            Redirect_to("FullPost.php?id={$PostId}");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="logo.ico"/>
    <title>Blog</title>
    <!-- Bootstrap -->
    <link href="1/css/bootstrap.css" rel="stylesheet">
    <!-- DL Menu CSS -->
    <link href="1/js/dl-menu/component.css" rel="stylesheet">
    <!-- Font Awesome StyleSheet CSS -->
    <link href="1/css/font-awesome.min.css" rel="stylesheet">
    <!-- Font Awesome StyleSheet CSS -->
    <link href="1/css/svg.css" rel="stylesheet">
    <!-- Pretty Photo CSS -->
    <link href="1/css/prettyPhoto.css" rel="stylesheet">
    <!-- Shortcodes CSS -->
    <link href="1/css/shortcodes.css" rel="stylesheet">
    <!-- Widget CSS -->
    <link href="1/css/widget.css" rel="stylesheet">
    <!-- Typography CSS -->
    <link href="1/css/typography.css" rel="stylesheet">
    <!-- Custom Main StyleSheet CSS -->
    <link href="1/style.css" rel="stylesheet">
    <!-- Color CSS -->
    <link href="1/css/color.css" rel="stylesheet">
    <!-- Responsive CSS -->
    <link href="1/css/responsive.css" rel="stylesheet">
    <style>
        .header-overlay {
            height: 100vh;
            position: absolute;
            top: 0;
            left: 0;
            width: 100vw;
            z-index: 1;
            background: black;
            opacity: 0.7;
        }
        
        .text-responsive {
            font-size: calc(100% + 1vw + 1vh);
        }
        
        p {
            word-break: keep-all;
        }
    </style>
</head>

<body>
    <!--iqoniq Wrapper Start-->
    <div class="iq_wrapper">
        <!--Header Wrap Start-->
        <header class="iq_header_1">
            <div class="container">
                <!--Logo Wrap Start-->
                <div class="iq_logo">
                    <a href="index.html"><img src="css1/images/logo.jpg" alt="Iqoniq Themes"></a>
                </div>
                <!--Logo Wrap Start-->
                <!--Top Strip Wrap Start-->
                <div class="iq_ui_element">
                    <!--Top Strip Wrap Start-->
                    <div class="iq_top_strip">
                        <div class="iq_top_contact pull-left">
                            <a href="#"> Call us : +234802784811</a>
                            <a href="#"> Email :  sra@voiceofvuna.com</a>
                        </div>
                        <div class="iq_time_wrap pull-right"><i class="fa fa-clock-o"></i> Mon - Sat : 09:00 am - 05:30 pm </div>
                    </div>
                    <!--Top Strip Wrap End-->
                    <!--Navigation wrap Start-->
                    <div class="navigation-wrapper pull-left">
                        <div class="navigation pull-left">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li>
                                    <a href="#">Paid Dues</a>
                                    <ul class="children">
                                        <li>
                                            <a href="100level.php">100 Level List</a>
                                        </li>
                                        <li>
                                            <a href="200level.php">200 Level List</a>
                                        </li>
                                        <li><a href="300level.php">300 Level List</a></li>
                                        <li>
                                            <a href="400level.php">400 Level List</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="about-us.html">About Us</a></li>
                                <li>
                                    <a href="sports.html">Sports</a>
                                </li>
                                <li class="active"><a href="blog-large.PHP">Blog</a>
                                </li>
                                <li><a href="event-calender.html">Event Calender</a>
                                </li>
                                <li>
                                    <a href="messages/index.php">Anonymous Message</a>
                                </li>
                                <li><a href="login.php">Admin</a>
                                </li>
                            </ul>
                        </div>
                        <!--DL Menu Start-->
                        <div id="mg-responsive-navigation" class="dl-menuwrapper">
                            <button class="dl-trigger">Open Menu</button>
                            <ul class="dl-menu">
                                <li class="menu-item mg-parent-menu">
                                    <a href="index.html">Home</a>
                                </li>
                                <li class="menu-item mg-parent-menu">
                                    <a href="#">Paid Dues</a>
                                    <ul class="dl-submenu">
                                        <a href="100level.php"></a>
                                </li>
                                <li>
                                    <a href="100level.php">100 level List</a>
                                </li>
                                <li>
                                    <a href="200level.php">200 Level List</a>
                                </li>
                                <li><a href="300level.php">300 Level List</a></li>
                                <li>
                                    <a href="400level.php">400 Level List</a>
                                </li>
                                </ul>
                                </li>
                                <li><a href="about-us.html ">About us</a></li>
                                </li>
                                <li class="menu-item mg-parent-menu "><a href="blog-large.PHP">Blog</a>
                                </li>
                                <li class="menu-item mg-parent-menu "><a href="event-calender.html">Event Calender</a>
                                </li>
                                <li class="menu-item mg-parent-menu ">
                                    <a href="messages/index.php">Anonymous Message</a>

                                </li>
                                <li class="menu-item mg-parent-menu ">
                                    <a href="login.php">Admin</a>
                                </li>

                            </ul>
                        </div>
                        <!--DL Menu END-->
                        <!--Search Wrap Start-->

                    </div>
                    <!--Navigation wrap End-->
                </div>
                <!--Top Strip Wrap End-->
            </div>
        </header>
        <!--Header Wrap End-->
        <!--Banner Wrap Start-->
        <div class="iner_banner">
            <div class="container">
                <h5>Blog</h5>
                <div class="banner_iner_capstion">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Blog - detail</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!--Banner Wrap End-->
        <!--iqoniq Content Start-->
        <div class="iq_content_wrap">
            <!--blog1_detail START-->
            <section>
                <!--blog_detail_page START-->
                <div class="blog1_detail">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">

                        <?php
                              global $connection;
                              if(isset($_GET["SearchButton"])){
                                $Search = $_GET["Search"];
                               $ViewQuery= "SELECT * FROM admin_panel 
                               WHERE datetime LIKE '%$Search%'
                               OR title LIKE '%$Search%'
                                 OR category LIKE '%$Search%'
                                 OR post LIKE '%$Search%'";
                               }else{
                               $PostIDFromURL = $_GET["id"];
                              $ViewQuery= "SELECT * FROM admin_panel WHERE id='$PostIDFromURL'
                                 ORDER BY id desc";
                              }
                        
                                  $Execute = mysqli_query($connection, $ViewQuery);
                                 while($DataRows=mysqli_fetch_array($Execute)){
                                   $PostId = $DataRows["id"];
                                  $DateTime = $DataRows["datetime"];
                                 $Title = $DataRows["title"];
                                 $Category = $DataRows["category"];
                                 $Admin = $DataRows["author"];
                                 $Image = $DataRows["image"];
                                 $Post = $DataRows["post"]; 
                           ?>
                                <!--blog_detail_page START-->
                                <div class="blog_detail_page">
                                    <figure>
                                        <img src="Upload/<?php echo $Image; ?>" alt="">
                                    </figure>
                                    <!--Heading Wrap Start-->
                                    <div class="iq_heading_1 text-left">
                                        <h4><?php echo htmlentities($Title);?></h4>
                                    </div>
                                    <!--Heading Wrap End-->
                                    <ul class="blog_detail_navi">
                                        <li>
                                        <?php echo htmlentities($DateTime);?>
                                        </li>
                                    </ul>
                                    <p><?php echo nl2br($Post); ?> </p>
                                 </div>
                                 <!--blog_detail_area end-->
                               
                                 <?php } ?>
                                </div>
                                
                            <div class="col-sm-offset-1 col-md-3">
                                <div class="aside-bar">
                                    <!--course_inrp_side_search START-->
                                    
                                    </div>
                                    <!--course_inrp_side_search end-->
                                    <!--coures_archives start-->
                                    <div class="widget widget_archive">
                                        <!--Widget Title Start-->
                                        <h5 class="widget-title"><span>our</span> Course</h5>
                                        <!--Widget Title End-->
                                        <ul>
                                <li>
                                    <a href="messages/index.php">Anonymous</a>
                                </li>
                                <li>
                                    <a href="blog-large.PHP">Blog</a>
                                </li>
                                <li>
                                    <a href="sports.html">Sports</a>
                                </li>
                                <li>
                                    <a href="event-calender.html">Calender</a>
                                </li>

                            </ul>
                                    </div>
                                    <!--coures_archives end-->
                                    <!--POPULAR START-->
                                   
                                        <!--POPULAR THUMB START-->
                                        <div class="popular_thumb">
                                            <figure>
                                                <img src="extra-images/popular-thumb3.jpg" alt="" />
                                            </figure>
                                            <!--COURES POPULAR CAPSTION START-->
                                          
                                            <!--COURES POPULAR CAPSTION END-->
                                        </div>
                                        <!--POPULAR THUMB END-->
                                    </div>
                                    <!--POPULAR END-->
                                    <!--COURES CATEGORIES START-->
                                   
                                            </div>
                                            <!--COURES POPULAR CAPSTION END-->
                                        </div>
                                        <!--POPULAR THUMB END-->
                                        <!--POPULAR THUMB START-->
                                      
                                        <!--POPULAR THUMB END-->
                                        <!--POPULAR THUMB START-->
                                        <div class="popular_thumb">
                                            <figure>
                                                <img src="extra-images/popular-thumb3.jpg" alt="" />
                                            </figure>
                                          
                                            <!--COURES POPULAR CAPSTION END-->
                                        </div>
                                        <!--POPULAR THUMB END-->
                                    </div>
                                    <!--POPULAR END-->
                                    <!--POPULAR START-->
                                  
                                    <!--POPULAR END-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--BLOG1 PAGE END-->
            </section>
        </div>
        <!--iqoniq Content End-->
        <!--Contact Info Wrap Start-->
        <div class="iq_contact_info ">
            <div class="container ">
                <ul>
                    <li>
                        <i class="fa fa-map-marker "></i>
                        <div class="iq_info_wrap ">
                            <h5>Veritas University</h5>
                            <p>Bwarri Area<span>Council</span></p>
                        </div>
                    </li>
                    <li>
                        <i class="fa fa-phone "></i>
                        <div class="iq_info_wrap ">
                            <h5>Contact Number</h5>
                            <span>+234802784811</span>
                            <span>+234730034134</span>
                        </div>
                    </li>
                    <li>
                        <i class="fa fa-phone "></i>
                        <div class="iq_info_wrap ">
                            <h5>Email;</h5>
                            <a href="sra@voiceofvuna.com ">sra@voiceofvuna.com</a>
                            <a href="help@voiceofvuna.com ">help@voiceofvuna.com</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!--Contact Info Wrap End-->
        <!--Footer Wrap Start-->
        <footer class="iq_footer_bg ">
            <div class="container ">
                <div class="row ">
                    <!--Widget About Start-->
                    <div class="col-md-3 col-sm-6 ">
                        <div class="iq_uni_title ">
                            <!--Widget Title Start-->
                            <h4>Availability<span>Periods</span></h4>
                            <!--Widget Title End-->
                            <ul>
                                <li><span>Moday - Friday</span> 08:00- 05:00</li>
                                <li><span>Saturday</span> Closed</li>
                                <li><span>Sunday</span> Closed</li>
                            </ul>
                        </div>
                    </div>
                    <!--Widget About End-->
                    <!--Widget Archive Start-->
                    <div class="col-md-3 col-sm-6 ">
                        <div class="widget widget_archive ">
                            <!--Widget Title Start-->
                            <h5 class="widget-title "><span>Our</span> Services</h5>
                            <!--Widget Title End-->
                            <!--Social Media Start-->
                            <ul>
                                <li>
                                    <a href="messages/index.php">Anonymous</a>
                                </li>
                                <li>
                                    <a href="blog-large.PHP">Blog</a>
                                </li>
                                <li>
                                    <a href="sports.html">Sports</a>
                                </li>
                                <li>
                                    <a href="event-calender.html">Calender</a>
                                </li>

                            </ul>
                            <!--Social Media End-->
                        </div>
                    </div>
                    <!--Widget Archive End-->
                    <!--Widget Flickr Start-->

                    <!--Widget Flickr End-->
                    <!--Widget News Letter Start-->
                    <div class="col-md-3 col-sm-6 ">
                        <div class="widget iq_footer_newsletter ">

                            <!--Widget Title Start-->
                            <h5 class="widget-title border-none "><span>Our</span> socials</h5>
                            <!--Widget Title Start-->
                            <ul class="iq_footer_social ">
                                <li>
                                    <a href="https://instagram.com/veritasblock?utm_medium=copy_link "><i class="fa fa-instagram "></i></a>
                                </li>
                                <li>
                                    <a href="# "><i class="fa fa-twitter "></i></a>
                                </li>
                                <li>
                                    <a href="# "><i class="fa fa-facebook "></i></a>
                                </li>
                                <li>
                                    <a href="# "><i class="fa fa-pinterest "></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--Widget News Letter End-->
                </div>
            </div>
        </footer>
        <!--Footer Wrap End-->
                <!--SEARCH section ENDS-->
            </div>
        </div>
    </div>
    <!--iqoniq Wrapper End-->`
    <!--Javascript Library-->
    <script src="1/js/jquery.js"></script>
    <!--Bootstrap core JavaScript-->
    <script src="1/js/bootstrap.min.js"></script>
    <!--Dl Menu Script-->
    <script src="1/js/dl-menu/modernizr.custom.js"></script>
    <script src="1/js/dl-menu/jquery.dlmenu.js"></script>
    <!--Pretty Photo JavaScript-->
    <script src="1/js/jquery.prettyPhoto.js"></script>
    <!--Custom JavaScript-->
    <script src="1/js/custom.js"></script>
</body>


</html>
</body>


</html>